package com.cg;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootMvcA6Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootMvcA6Application.class, args);
	}

}
