package com.cg;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootWebMvcA9Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootWebMvcA9Application.class, args);
	}

}
