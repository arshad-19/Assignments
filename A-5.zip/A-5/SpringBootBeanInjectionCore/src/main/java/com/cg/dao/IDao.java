package com.cg.dao;

public interface IDao {
public String getName() ;
}
