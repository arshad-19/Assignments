package com.cg.exception;

public class EmpNotFoundException extends Exception{
	public EmpNotFoundException() {
		super();
	}
	
	public EmpNotFoundException(String arg0) {
		super(arg0);
	}

}
